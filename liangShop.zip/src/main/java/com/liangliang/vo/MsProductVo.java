/**
 * @description: 功能描述：()
 * @copyright: Copyright (c) 2019
 * @company: 亮亮商城
 * @author: 
 * @version: 2.0
 * @date:  2019年5月13日 上午9:00:26
*/
package com.liangliang.vo;

/**
 * @description: 功能描述 ()
 * @copyright: Copyright (c) 2019
 * @company: 亮亮商城
 * @author:
 * @version: 2.0
 * @date:  2019年5月13日 上午9:00:26
 */
public class MsProductVo extends ConstomProduct {
	private ConstomProduct constomProduct;

	/**
	 * constomProduct
	 * 
	 * @return the constomProduct
	 */
	public ConstomProduct getConstomProduct() {
		return constomProduct;
	}

	/**
	 * @param constomProduct
	 *            the constomProduct to set
	 */
	public void setConstomProduct(ConstomProduct constomProduct) {
		this.constomProduct = constomProduct;
	}

}

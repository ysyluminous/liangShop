/**
 * @description: 功能描述：()
 * @copyright: Copyright (c) 2019
 * @company: 亮亮商城
 * @author: 
 * @version: 2.0
 * @date:  2019年5月13日 下午4:04:40
*/
package com.liangliang.vo;

/**
 * @description: 功能描述 ()
 * @copyright: Copyright (c) 2019
 * @company: 亮亮商城
 * @author:
 * @version: 2.0
 * @date:  2019年5月13日 下午4:04:40
 */
public class MsMerchantVo {
	private ConstomMsmerchant constomMsmerchant;

	public ConstomMsmerchant getConstomMsmerchant() {
		return constomMsmerchant;
	}

	public void setConstomMsmerchant(ConstomMsmerchant constomMsmerchant) {
		this.constomMsmerchant = constomMsmerchant;
	}
}

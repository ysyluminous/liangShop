/**
 * @description: 功能描述：()
 * @copyright: Copyright (c) 2019
 * @company: 亮亮商城
 * @author: 
 * @version: 2.0
 * @date:  2019年5月13日 下午8:30:20
*/
package com.liangliang.vo.order;

/**
 * @description: 功能描述 ()
 * @copyright: Copyright (c) 2019
 * @company: 亮亮商城
 * @author:
 * @version: 2.0
 * @date:  2019年5月13日 下午8:30:20
 */
public class MsOrderVo {
	private ConstomOrder constomOrder;

	/**
	 * constomOrder
	 * 
	 * @return the constomOrder
	 */
	public ConstomOrder getConstomOrder() {
		return constomOrder;
	}

	/**
	 * @param constomOrder
	 *            the constomOrder to set
	 */
	public void setConstomOrder(ConstomOrder constomOrder) {
		this.constomOrder = constomOrder;
	}

}

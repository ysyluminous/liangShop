/**
 * @description: 功能描述：()
 * @copyright: Copyright (c) 2019
 * @company: 亮亮商城
 * @author: 
 * @version: 2.0
 * @date:  2019年5月12日 下午8:30:11
*/
package com.liangliang.vo.order;

import com.liangliang.entity.MsOrder;

/**
 * @description: 功能描述 ()
 * @copyright: Copyright (c) 2019
 * @company: 亮亮商城
 * @author:
 * @version: 2.0
 * @date:  2019年5月12日 下午8:30:11
 */
public class ConstomOrder extends MsOrder {

}

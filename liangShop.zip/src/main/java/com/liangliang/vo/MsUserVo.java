/**
 * @description: 功能描述：()
 * @copyright: Copyright (c) 2019
 * @company: 亮亮商城
 * @author: 
 * @version: 2.0
 * @date:  2019年5月13日 下午8:30:20
*/
package com.liangliang.vo;

/**
 * @description: 功能描述 ()
 * @copyright: Copyright (c) 2019
 * @company: 亮亮商城
 * @author:
 * @version: 2.0
 * @date:  2019年5月13日 下午8:30:20
 */
public class MsUserVo {
	private ConstomUser constomUser;

	/**
	 * constomUser
	 * 
	 * @return the constomUser
	 */
	public ConstomUser getConstomUser() {
		return constomUser;
	}

	/**
	 * @param constomUser
	 *            the constomUser to set
	 */
	public void setConstomUser(ConstomUser constomUser) {
		this.constomUser = constomUser;
	}

}
